import dataclasses
import random
from typing import Dict, List, Type
from copy import deepcopy
import re
import copy
# =====================
# CONSTANTS
# =====================
ROWS, COLS = 8, 8
RED = "R"
BLUE = "B"

# =====================
# PIECE
# =====================
class Piece:
    def __init__(self, row, col, color):
        self.row = row
        self.col = col
        self.color = color
        self.king = False

    def move(self, row, col):
        self.row = row
        self.col = col

    def make_king(self):
        self.king = True


# =====================
# BOARD (Spanish Rules)
# =====================
class Board:
    def __init__(self):
        self.board = []
        self.create_board()

    def create_board(self):
        self.board = []
        for row in range(ROWS):
            self.board.append([])
            for col in range(COLS):
                if col % 2 == (row + 1) % 2:
                    if row < 3:
                        self.board[row].append(Piece(row, col, RED))
                    elif row > 4:
                        self.board[row].append(Piece(row, col, BLUE))
                    else:
                        self.board[row].append(None)
                else:
                    self.board[row].append(None)

    def get_piece(self, row, col):
        return self.board[row][col]

    def move(self, piece, row, col):
        self.board[piece.row][piece.col] = None
        self.board[row][col] = piece
        piece.move(row, col)

        if piece.color == RED and row == ROWS - 1:
            piece.make_king()
        if piece.color == BLUE and row == 0:
            piece.make_king()

    def remove(self, pieces):
        for p in pieces:
            self.board[p.row][p.col] = None

    def get_all_pieces(self, color):
        return [p for row in self.board for p in row if p and p.color == color]

    def has_moves(self, color):
        for piece in self.get_all_pieces(color):
            if self.get_valid_moves(piece, False):
                return True
        return False

    def player_has_capture(self, color):
        for piece in self.get_all_pieces(color):
            if self.get_valid_moves(piece, True):
                return True
        return False

    def get_valid_moves(self, piece, force_capture=False):
        moves = {}

        if piece.king:
            directions = [(-1, -1), (-1, 1), (1, -1), (1, 1)]
            for dr, dc in directions:
                r, c = piece.row + dr, piece.col + dc
                skipped = None
                while 0 <= r < ROWS and 0 <= c < COLS:
                    current = self.get_piece(r, c)
                    if current is None:
                        if skipped:
                            moves[(r, c)] = [skipped]
                        elif not force_capture:
                            moves[(r, c)] = []
                    elif current.color == piece.color:
                        break
                    else:
                        if skipped is None:
                            skipped = current
                        else:
                            break
                    r += dr
                    c += dc
        else:
            step = 1 if piece.color == RED else -1
            for dc in (-1, 1):
                r = piece.row + step
                c = piece.col + dc
                if 0 <= r < ROWS and 0 <= c < COLS:
                    target = self.get_piece(r, c)
                    if target is None and not force_capture:
                        moves[(r, c)] = []
                    elif target and target.color != piece.color:
                        jr, jc = r + step, c + dc
                        if 0 <= jr < ROWS and 0 <= jc < COLS and self.get_piece(jr, jc) is None:
                            moves[(jr, jc)] = [target]

        if force_capture:
            moves = {k: v for k, v in moves.items() if v}

        return moves


# =====================
# GAME ACTION (SAFE)
# =====================
@dataclasses.dataclass(frozen=True)
class DamasMove:
    move_index: int


# =====================
# DAMAS GAME (LLM READY)
# =====================
class DamasGame:
    def __init__(self):
        self.board = Board()
        self.current_player = RED
        self.game_over = False
        self.winner = None
        self.history = []

        # --- NEW: track piece that must continue capturing ---
        self.pending_piece = None
        self.force_capture = False

    # ---- API ----
    def get_player_ids(self) -> List[str]:
        return [RED, BLUE]

    def get_current_player(self) -> str:
        return self.current_player

    def get_action_schema(self) -> Type[DamasMove]:
        return DamasMove

    def is_game_over(self) -> bool:
        return self.game_over

    def get_scores(self) -> Dict[str, float]:
        if self.winner is None:
            return {RED: 0.5, BLUE: 0.5}
        return {
            self.winner: 1.0,
            (BLUE if self.winner == RED else RED): 0.0,
        }

    # ---- MOVE GENERATION ----
    #
    def get_all_valid_moves(self, color):
        moves = []

        # --- NEW: if a piece must continue capturing, only allow its moves ---
        if self.pending_piece:
            piece = self.pending_piece
            valid = self.board.get_valid_moves(piece, force_capture=True)
            for (r, c), skipped in valid.items():
                moves.append({
                    "from": (piece.row, piece.col),
                    "to": (r, c),
                    "skipped": skipped,
                })
            return moves

        # --- NORMAL turn ---
        force_capture = self.board.player_has_capture(color)

        for piece in self.board.get_all_pieces(color):
            valid = self.board.get_valid_moves(piece, force_capture)
            for (r, c), skipped in valid.items():
                moves.append({
                    "from": (piece.row, piece.col),
                    "to": (r, c),
                    "skipped": skipped,
                })

        return moves

    # ---- APPLY MOVE ----
    #
    def make_move(self, action: DamasMove) -> bool:
          moves = self.get_all_valid_moves(self.current_player)
          if not moves or action.move_index >= len(moves):
              return False

          m = moves[action.move_index]
          piece = self.board.get_piece(*m["from"])
          if not piece:
              return False

          self.board.move(piece, *m["to"])

          # --- REMOVE captured pieces ---
          if m["skipped"]:
              self.board.remove(m["skipped"])

              # --- CHECK for continued capture with same piece ---
              next_captures = self.board.get_valid_moves(piece, force_capture=True)
              if next_captures:
                  # same player continues
                  self.pending_piece = piece
                  self.force_capture = True

                  self.history.append(
                      f"{self.current_player}: {m['from']} -> {m['to']} (capture)"
                  )
                  self.history = self.history[-10:]
                  return True  # do NOT switch turn yet

          # --- capture chain ended ---
          self.pending_piece = None
          self.force_capture = False

          self.history.append(
              f"{self.current_player}: {m['from']} -> {m['to']}"
          )
          self.history = self.history[-10:]

          # --- check for game over ---
          opponent = BLUE if self.current_player == RED else RED
          if not self.board.get_all_pieces(opponent) or not self.board.has_moves(opponent):
              self.game_over = True
              self.winner = self.current_player
              return True

          # --- switch turn ---
          self.current_player = opponent
          return True

    # ---- PROMPT RENDERING ----
    def get_state_representation(self) -> str:
        lines = []
        lines.append(f"Turn: {self.current_player}")
        lines.append("   0 1 2 3 4 5 6 7")

        for r in range(8):
            row = []
            for c in range(8):
                p = self.board.get_piece(r, c)
                if not p:
                    row.append(".")
                else:
                    if p.color == RED:
                        row.append("R" if p.king else "r")
                    else:
                        row.append("B" if p.king else "b")
            lines.append(f"{r}  " + " ".join(row))

        if self.board.player_has_capture(self.current_player):
            lines.append("\n⚠️ CAPTURE IS MANDATORY")

        lines.append("\nRecent moves:")
        lines.append("\n".join(self.history) if self.history else "None")

        lines.append("\nLegal moves:")
        for i, m in enumerate(self.get_all_valid_moves(self.current_player)):
            cap = "x" if m["skipped"] else "-"
            lines.append(f"{i}: {m['from']} {cap}> {m['to']}")

        lines.append("\nChoose ONE move by index.")
        return "\n".join(lines)
    #
    def render_board_only(self) -> str:
        lines = []
        lines.append("   0 1 2 3 4 5 6 7")
        for r in range(8):
            row = []
            for c in range(8):
                p = self.board.get_piece(r, c)
                if not p:
                    row.append(".")
                else:
                    if p.color == RED:
                        row.append("R" if p.king else "r")
                    else:
                        row.append("B" if p.king else "b")
            lines.append(f"{r}  " + " ".join(row))
        return "\n".join(lines)

    #
    def render_board_only(self) -> str:
        """
        Human-friendly DAMA board rendering.
        __  = invalid (light) square
        .   = empty playable square
        R/B = man
        R*/B* = king
        """

        lines = []

        # Column labels
        lines.append("     0   1   2   3   4   5   6   7")

        for r in range(8):
            row_cells = []
            for c in range(8):
                # Light square → invalid
                if (r + c) % 2 == 0:
                    row_cells.append("_")
                else:
                    p = self.board.get_piece(r, c)
                    if not p:
                        row_cells.append(" .")
                    else:
                        if p.color == RED:
                            row_cells.append("R*" if p.king else " R")
                        else:
                            row_cells.append("B*" if p.king else " B")

            lines.append(f" {r} | " + " | ".join(row_cells) + " |")

        return "\n".join(lines)


# =====================
# BASELINE BOTS
# =====================
class RandomBot:
    name = "random_bot"

    def prompt(self, text, schema=None):
        indices = [
            int(line.split(":")[0])
            for line in text.splitlines()
            if ":" in line and line.strip()[0].isdigit()
        ]
        return schema(move_index=random.choice(indices))


class GreedyBot:
    name = "greedy_bot"

    def prompt(self, text, schema=None):
        capture_moves = []
        normal_moves = []

        for line in text.splitlines():
            line = line.strip()
            if not line or ":" not in line:
                continue

            prefix = line.split(":", 1)[0]
            if not prefix.isdigit():
                continue

            idx = int(prefix)

            if "x>" in line:
                capture_moves.append(idx)
            else:
                normal_moves.append(idx)

        # Spanish rules: capture is mandatory, so prefer capture
        if capture_moves:
            return schema(move_index=capture_moves[0])

        if normal_moves:
            return schema(move_index=normal_moves[0])

        # No legal moves → invalid (forfeit)
        return schema(move_index=0)



# =====================
# SIMPLE LOCAL RUN (NO KAGGLE)
# =====================
def play_local(p1, p2, max_moves=200):
    game = DamasGame()
    players = {RED: p1, BLUE: p2}
    move_count = 0

    print("=== GAME START ===")
    print(game.render_board_only())
    print()

    while not game.is_game_over() and move_count < max_moves:
        current = game.get_current_player()
        player = players[current]

        state = game.get_state_representation()
        action = player.prompt(state, schema=DamasMove)

        valid_moves = game.get_all_valid_moves(current)
        if action.move_index >= len(valid_moves):
            print(f"❌ INVALID MOVE by {player.name}")
            game.winner = BLUE if current == RED else RED
            break

        chosen = valid_moves[action.move_index]

        print(f"\nMove {move_count + 1}")
        print(f"Player: {current} ({player.name})")
        print(f"Action: {chosen['from']} -> {chosen['to']}")
        if chosen["skipped"]:
            print(f"Captured: {len(chosen['skipped'])} piece(s)")

        ok = game.make_move(action)
        if not ok:
            print(f"❌ MOVE REJECTED: {player.name}")
            game.winner = BLUE if current == RED else RED
            break

        print(game.render_board_only())
        move_count += 1

    print("\n=== GAME OVER ===")
    print("Winner:", game.winner)




class AdvancedDamasBot:
    name = "advanced_damas_bot_v3"

    def __init__(self):
        # strategy weights
        self.PROMOTION_WEIGHT = 5
        self.DEFENSE_PENALTY = -3
        self.CENTER_BONUS = 0.5
        self.SUPPORT_BONUS = 0.4
        self.MATERIAL_WEIGHT = 1.5

    # =====================================================
    # MAIN ENTRY
    # =====================================================
    def prompt(self, text, schema=None):
        board = self._parse_board(text)
        moves = self._parse_moves(text)

        if not moves:
            return schema(move_index=0)

        best_score = float("-inf")
        best_move = list(moves.keys())[0]

        for idx, move in moves.items():
            # simulate move
            new_board = self._simulate_move(board, move)

            # evaluate resulting position
            score = self._evaluate_position(new_board, move)

            if score > best_score:
                best_score = score
                best_move = idx

        return schema(move_index=best_move)

    # =====================================================
    # PARSE BOARD
    # =====================================================
    def _parse_board(self, text):
        lines = text.splitlines()
        grid = []
        turn = "R"

        for line in lines:
            line = line.strip()

            if line.startswith("Turn:"):
                turn = line.split(":")[1].strip()

            # board rows start with number
            if line and line[0].isdigit() and "." in line:
                parts = line.split()[1:]
                grid.append(parts)

        return {"grid": grid, "turn": turn}

    # =====================================================
    # PARSE MOVES
    # =====================================================
    def _parse_moves(self, text):
        moves = {}
        pattern = r"(\d+): \((\d+), (\d+)\) -> \((\d+), (\d+)\)"

        for line in text.splitlines():
            match = re.search(pattern, line)
            if match:
                idx, r1, c1, r2, c2 = map(int, match.groups())
                moves[idx] = (r1, c1, r2, c2)

        return moves

    # =====================================================
    # SIMULATE MOVE
    # =====================================================
    def _simulate_move(self, board, move):
        new_board = copy.deepcopy(board)
        grid = new_board["grid"]

        r1, c1, r2, c2 = move
        piece = grid[r1][c1]

        # move piece
        grid[r1][c1] = "."
        grid[r2][c2] = piece

        # capture detection (jump move)
        if abs(r2 - r1) == 2:
            cr = (r1 + r2) // 2
            cc = (c1 + c2) // 2
            grid[cr][cc] = "."

        return new_board

    # =====================================================
    # POSITION EVALUATION
    # =====================================================
    def _evaluate_position(self, board, last_move):
        score = 0

        score += self._material_score(board)
        score += self._promotion_score(last_move, board)
        score += self._defense_score(last_move, board)
        score += self._center_score(last_move)
        score += self._support_score(last_move, board)

        return score

    # =====================================================
    # MATERIAL (piece count advantage)
    # =====================================================
    def _material_score(self, board):
        grid = board["grid"]
        my_turn = board["turn"]

        my_piece = "r" if my_turn == "R" else "b"
        enemy_piece = "b" if my_piece == "r" else "r"

        my_count = 0
        enemy_count = 0

        for row in grid:
            for cell in row:
                if cell == my_piece:
                    my_count += 1
                elif cell == enemy_piece:
                    enemy_count += 1

        return (my_count - enemy_count) * self.MATERIAL_WEIGHT

    # =====================================================
    # PROMOTION GREEDINESS
    # =====================================================
    def _promotion_score(self, move, board):
        r1, c1, r2, c2 = move
        grid = board["grid"]
        piece = grid[r2][c2]

        if piece == "r":
            if r2 == 7:
                return self.PROMOTION_WEIGHT
            return (r2 - r1) * 0.3

        if piece == "b":
            if r2 == 0:
                return self.PROMOTION_WEIGHT
            return (r1 - r2) * 0.3

        return 0

    # =====================================================
    # DEFENSE — avoid squares enemy can capture
    # =====================================================
    def _defense_score(self, move, board):
        r1, c1, r2, c2 = move
        grid = board["grid"]
        piece = grid[r2][c2]

        enemy = "b" if piece == "r" else "r"

        if self._is_square_attacked(r2, c2, grid, enemy):
            return self.DEFENSE_PENALTY

        return 0

    def _is_square_attacked(self, row, col, grid, enemy):
        directions = [(-1, -1), (-1, 1), (1, -1), (1, 1)]

        for dr, dc in directions:
            er = row + dr
            ec = col + dc

            if 0 <= er < 8 and 0 <= ec < 8:
                if grid[er][ec] == enemy:
                    jump_r = row - dr
                    jump_c = col - dc

                    if 0 <= jump_r < 8 and 0 <= jump_c < 8:
                        if grid[jump_r][jump_c] == ".":
                            return True
        return False

    # =====================================================
    # CENTER CONTROL
    # =====================================================
    def _center_score(self, move):
        r1, c1, r2, c2 = move

        if 2 <= r2 <= 5 and 2 <= c2 <= 5:
            return self.CENTER_BONUS
        return 0

    # =====================================================
    # PIECE SUPPORT (defensive structure)
    # =====================================================
    def _support_score(self, move, board):
        r1, c1, r2, c2 = move
        grid = board["grid"]
        piece = grid[r2][c2]

        allies = 0

        for dr, dc in [(-1, -1), (-1, 1), (1, -1), (1, 1)]:
            nr = r2 + dr
            nc = c2 + dc

            if 0 <= nr < 8 and 0 <= nc < 8:
                if grid[nr][nc] == piece:
                    allies += 1

        return allies * self.SUPPORT_BONUS
